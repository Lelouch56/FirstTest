

package trial;


import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;



public class LaunchBrowser {
	WebDriver driver;
	
	@Test
	public void setUp()
	{
		 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		 driver.get("https://practice.automationtesting.in/my-account/");
		 driver.manage().window().maximize();
		 
		 

	
		
		
		WebElement searchInput = driver.findElement(By.cssSelector("input[type='text'][name='username'][id='username']"));
        searchInput.sendKeys("abc@gmail.com");
        

        WebElement searchInput2 = driver.findElement(By.cssSelector("input[type='password'][name='password'][id='password']"));
        searchInput2.sendKeys("abc@123");
        searchInput2.sendKeys(Keys.RETURN);


		

		}
	}



